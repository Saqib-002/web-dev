blogs = [
    {
        title: "How to get started with Python",
        content: "This is content Python",
        slug: "python-learn"
    },
    {
        title: "How to get started with Js",
        content: "This is content Js",
        slug: "js-learn"
    },
    {
        title: "How to get started with Django",
        content: "This is content Django",
        slug: "python-django-learn"
    },
    {
        title: "How to get started with CSS",
        content: "This is content Css",
        slug: "css-learn"
    },
]


module.exports = blogs;